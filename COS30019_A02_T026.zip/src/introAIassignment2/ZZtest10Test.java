package introAIassignment2;

import static org.junit.Assert.*;

import org.junit.*;

public class ZZtest10Test {

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void test10Test10() {
		assertTrue(true);
	}

}
